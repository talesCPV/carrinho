
const screen = [768,720];

const pixel = [screen[0]/256, screen[1]/240];

const bd = new Object;
    bd.x = 141;
    bd.y = 120;
    bd.p = 18;


//alert(pixel)

let dots = [];

function setup() {
    createCanvas(screen[0],screen[1]);
    background(0, 0, 0);
    drawBord();

    for(let y=0; y<=29; y++){
        dots.push([]);
        for(let x=0; x<=26;x++){
            let color = get(bd.x + x * bd.p , bd.y + y * bd.p);
            if(color[2] == 0){
                dots[y].push([x,y]);
            }
        }
    }    
}

function draw() {
    background(0, 0, 0);
    drawBord();
    drawDots();

}

const squares = [[0,0,27,30],[13,0,1,4],
                [2,2,3,2],[7,2,4,2],
                [2,6,3,1],[7,6,1,7],[10,6,7,1],[13,7,1,3],
                [0,9,5,4],[8,9,3,1],
                [10,12,7,4],
                [0,15,5,4],[7,15,1,4],
                [10,18,7,1],[13,19,1,3],
                [2,21,3,1],[7,21,4,1],[4,22,1,3],
                [0,24,2,1],[10,24,7,1],[13,25,1,3],
                [2,27,9,1],[7,24,1,3]];


function drawBord(){

    noFill();
    stroke(0,0,255);
    strokeWeight(pixel);

    for(let i=0; i<squares.length; i++){
        drawMirror("R",[ bd.x + squares[i][0] * bd.p , bd.y + squares[i][1] * bd.p, squares[i][2] * bd.p, squares[i][3] * bd.p]);
    }


}

function drawMirror(T,D){

    const x = D[0];
    const y = D[1];
    const w = D[2];
    const h = D[3];
    const rad = 0;
    const offset = 5;

    if(T == "L"){
        line(x,y,w,h);
        line(screen[0]-x,y,screen[0]-w,h);
    }else if(T == "R"){
        rect(x,y,w,h,rad);
        rect(screen[0]-x-w,y,w,h,rad);

        rect(x+offset,y+offset,w-2*offset,h-2*offset,rad);
        rect(screen[0]-x-w+offset,y+offset,w-2*offset,h-2*offset,rad);
    }

}


function drawDots(){
    const diam = 5;

    noFill();
    stroke(255,255,0);
    strokeWeight(pixel);

    for(let y=0; y<dots.length; y++){
        for(let x=0; x<dots[y].length;x++){
//            alert([dots[y][x],diam])
            circle(bd.x + dots[y][x][0] * bd.p , bd.y + dots[y][x][1] * bd.p,diam);
        }
    }



//    for(let =0; i<dots.length;i++){
//        alert([dots[i],diam])
//        circle(dots[i][0],dots[i][1],diam);
//    }

/*    
    for(let x=1; x<=26;x++){
        for(let y=1; y<=29; y++){
            circle(bd.x + x * bd.p , bd.y + y * bd.p,diam);
        }
    }
*/
}